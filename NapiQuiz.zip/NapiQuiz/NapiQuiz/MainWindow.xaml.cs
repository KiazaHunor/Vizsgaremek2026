﻿using NapiQuiz.Models;
using NapiQuiz.Views;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace NapiQuiz
{
    public partial class MainWindow : Window
    {
        private readonly User _loggedInUser;

        public MainWindow(User loggedInUser)
        {
            InitializeComponent();
            _loggedInUser = loggedInUser;
        }

        private void UserButton_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();

            var userWindow = new UserWindow(_loggedInUser);
            userWindow.ShowDialog();

            this.Show();
        }

        private void AdminButton_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            var adminLoginWindow = new AdminLoginWindow();
            adminLoginWindow.ShowDialog();
            this.Show();
        }

        private void LeaderboardButton_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            var leaderboardWindow = new LeaderboardWindow();
            leaderboardWindow.ShowDialog();
            this.Show();
        }
    }
}