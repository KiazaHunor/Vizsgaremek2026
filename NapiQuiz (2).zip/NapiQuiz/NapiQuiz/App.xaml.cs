﻿using NapiQuiz.Data;
using System.Configuration;
using System.Data;
using System.Windows;


namespace NapiQuiz
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            using var db = new QuizDbContext();

            var user = db.Users.FirstOrDefault();

            if (user != null)
            {
                var main = new MainWindow(user);
                main.Show();
            }
            else
            {
                MessageBox.Show("Nincs user az adatbázisban!");
                Shutdown();
            }

            base.OnStartup(e);
        }
    }
}