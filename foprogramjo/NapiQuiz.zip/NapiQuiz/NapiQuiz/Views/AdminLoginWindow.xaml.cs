﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using NapiQuiz.Models;
namespace NapiQuiz.Views
{
    public partial class AdminLoginWindow : Window
    {
        private const string AdminPassword = "admin123";

        public AdminLoginWindow()
        {
            InitializeComponent();
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            if (AdminPasswordBox.Password == AdminPassword)
            {
                new AdminWindow().ShowDialog();
                Close();
            }
            else
            {
                MessageBox.Show("Hibás jelszó!");
            }

        }
        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}